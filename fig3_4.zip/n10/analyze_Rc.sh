#!/bin/bash

ARRAY=()
for u in `seq 40 5 110`;do
ARRAY=(${ARRAY[@]} "$u")
done
#ARRAYU=(20)
lenU=${#ARRAY[@]}

ARRAYL=()
for u in `seq 200 5 200`;do
ARRAYL=(${ARRAYL[@]} "$u")
done
#ARRAYU=(20)
lenL=${#ARRAYL[@]}


no2=5
n1=$(($no2-1))
after=$(($no2+1))


echo "RF.dat" > fname.dat
########################

for (( k=0; k< $lenU; k++ )); do
for (( l=0; l< $lenL; l++ )); do

 echo "grepping and averaging"
 echo "U="${ARRAY[$k]} "L="${ARRAYL[$l]}
 grep -m1 -A$after -h " Saf avg" rU${ARRAY[$k]}Th90n$n*L${ARRAYL[$l]}r*.out  > teste1.dat
 sed -i " s/    0           $n1 /${ARRAY[$k]}  ${ARRAYL[$l]}  /g" teste1.dat >> testnew.dat
 sed -i " s/    0           $no2 /${ARRAY[$k]}  ${ARRAYL[$l]}  /g" teste1.dat
 sed -i " s/ +-/   /g" teste1.dat
 grep -vwE "NaN|Saf|  0     |\-\-" teste1.dat > ttteste.dat

 sleep 0.2s
 ./grepRcP
 sleep 0.2s

done
done


echo "finished"
