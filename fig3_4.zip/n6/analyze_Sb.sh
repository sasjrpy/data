#!/bin/bash
ARRAY=(50 55 60)
lenU=${#ARRAY[@]}


ARRAL=(10 20 30 40 50 60 70 80 90 100)
lenL=${#ARRAL[@]}

no2=4
n=$((2*$no2))

echo "Scdw.dat" > fname.dat
########################

for (( k=0; k< $lenU; k++ )); do
for (( j=0; j< $lenL; j++ )); do

 echo "grepping and averaging"
 echo "g="${ARRAY[$k]}" L=""${ARRAL[$j]}"
 grep -B1 -h "Spin" r*U"${ARRAY[$k]}"n"$n"L"${ARRAL[$j]}"r*  > teste1.dat
 sed -i " s/           $no2           $no2/${ARRAY[$k]}           ${ARRAL[$j]}       /g" teste1.dat
 sed -i " s/ +-/   /g" teste1.dat
 grep -vwE "NaN|Spin|\-\-" teste1.dat > ttteste.dat

 sleep 0.2s
 ./grep
 sleep 0.2s

done
done
rm ttteste.dat
rm teste1.dat
rm fname.dat 
echo "finished"
